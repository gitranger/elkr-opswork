        module ChefCompat
          CHEF_UPSTREAM_VERSION="12.16.14"
        end
