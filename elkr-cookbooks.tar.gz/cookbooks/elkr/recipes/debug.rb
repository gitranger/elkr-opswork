#
# Cookbook Name:: elkr
# Recipe:: debug
#
# Copyright (c) 2016 The Authors, All Rights Reserved.


#other_ip = search(:node, "run_list:*elkr??elasticsearch*")[0]['ipaddress']
#Chef::Log.info("********** Hello, World! #{other_ip} **********")

